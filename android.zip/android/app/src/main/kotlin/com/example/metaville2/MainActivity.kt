package com.example.metaville2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
